import React, { useEffect, useState } from "react";
import axios from "axios";
import './Form.css';



export default function Form() {
  const [state, setState] = useState({ name: "" });
  const [data, setData] = useState([]);
  const [editID, setEditID] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:3000/data")
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  function FormSubmit(e) {
    e.preventDefault();
    const newID = (data.length + 1).toString();
    if (editID !== null) {
      axios
        .put(`http://localhost:3000/data/${editID}`, { id: editID, name: state.name })
        .then((response) => {
          setData((prevData) =>
            prevData.map((item) =>
              item.id === editID ? response.data : item
            )
          );
          setState({ name: "" });
          setEditID(null);
        })
        .catch((error) => console.error("Error editing data:", error));
    } else {
      axios
        .post("http://localhost:3000/data", { ...state, id: newID })
        .then((response) => {
          setData((prevData) => [...prevData, response.data]);
          setState({ name: "" });
        })
        .catch((error) => console.error("Error submitting data:", error));
    }
  }

  function Deletedata(id) {
    axios
      .delete(`http://localhost:3000/data/${id}`)
      .then(() => {
        setData((prevData) => prevData.filter((item) => item.id !== id));
      })
      .catch((error) => console.error("Error deleting data:", error));
  }

  function Editdata(id) {
    const itemToEdit = data.find((item) => item.id === id);
    setState({ name: itemToEdit.name });
    setEditID(id);
  }

  return (
    <div className="form-container">
      <form onSubmit={FormSubmit} className="form">
        <input
          className="input"
          type="text"
          value={state.name}
          placeholder="Enter the name"
          onChange={(e) => setState({ name: e.target.value })}
        />
        <button type="submit" className="submit-btn">
          {editID ? "Update" : "Submit"}
        </button>
      </form>

      <ul className="data-list">
        {data.map((el) => (
          <li key={el.id} className="data-item">
            {el.id} :  {el.name}
            <div className="action-buttons">
              <button
                type="button"
                onClick={() => Deletedata(el.id)}
                className="delete-btn"
              >
                Delete
              </button>
              <button
                type="button"
                onClick={() => Editdata(el.id)}
                className="edit-btn"
              >
                Edit
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}