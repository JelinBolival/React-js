import React from 'react'

export default function Contact() {
  return (
    <div>
      <h1>contact</h1>
    </div>
  )
}
