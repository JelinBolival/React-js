import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteStudent, fetchStudents } from '../redux/actions';

const StudentList = () => {
  const dispatch = useDispatch();
  const { students, loading, error } = useSelector((state) => state.students);

  useEffect(() => {
    dispatch(fetchStudents());
  }, [dispatch]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h2>Student List</h2>
      <ul>
        {students.map((student) => (
          <li key={student.id}>
            {student.name} <button onClick={() => dispatch(deleteStudent(student.id))}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StudentList;
