import React from 'react';
import { useDispatch } from 'react-redux';
import { deleteStudent } from '../redux/actions';

const StudentDetails = ({ student }) => {
  const dispatch = useDispatch();

  const handleDelete = () => {
  };

  return (
    <div>
      <h3>{student.name}</h3>
      <button onClick={handleDelete}>Delete</button>
    </div>
  );
};

export default StudentDetails;
