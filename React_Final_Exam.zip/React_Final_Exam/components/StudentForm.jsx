import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addStudent } from '../redux/actions';

const StudentForm = () => {
  const [student, setStudent] = useState({ name: '', rollNumber: '', class: '' });
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addStudent(student));
    setStudent({ name: '', rollNumber: '', class: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Name"
        value={student.name}
        onChange={(e) => setStudent({ ...student, name: e.target.value })}
      />
      <input
        type="text"
        placeholder="Roll Number"
        value={student.rollNumber}
        onChange={(e) => setStudent({ ...student, rollNumber: e.target.value })}
      />
      <input
        type="text"
        placeholder="Class"
        value={student.class}
        onChange={(e) => setStudent({ ...student, class: e.target.value })}
      />
      <button type="submit">Add Student</button>
    </form>
  );
};

export default StudentForm;
  