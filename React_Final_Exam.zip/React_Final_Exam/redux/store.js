import { legacy_createStore as createStore, applyMiddleware, combineReducers } from 'redux';
import { thunk } from 'redux-thunk'; // Ensure correct import
import studentReducer from './reducers';

const rootReducer = combineReducers({
  students: studentReducer,
});

const store = createStore(
  rootReducer,
  applyMiddleware(thunk)  // Use thunk correctly
);

export default store;
