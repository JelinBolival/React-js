import {
    FETCH_STUDENTS_REQUEST,
    FETCH_STUDENTS_SUCCESS,
    FETCH_STUDENTS_FAILURE,
    DELETE_STUDENT,
    ADD_STUDENT,
  } from './actions';  // Imported action types
  
  const initialState = {
    loading: false,
    students: [],
    error: '',
  };
  
  const studentReducer = (state = initialState, action) => {
    switch (action.type) {
      case FETCH_STUDENTS_REQUEST:
        return { ...state, loading: true };
      case FETCH_STUDENTS_SUCCESS:
        return { ...state, loading: false, students: action.payload, error: '' };
      case FETCH_STUDENTS_FAILURE:
        return { ...state, loading: false, students: [], error: action.payload };
      case DELETE_STUDENT:
        return {
          ...state,
          students: state.students.filter((student) => student.id !== action.payload),
        };
      case ADD_STUDENT:
        return {
          ...state,
          students: [...state.students, action.payload],
        };
      default:
        return state;
    }
  };
  
  export default studentReducer;
  