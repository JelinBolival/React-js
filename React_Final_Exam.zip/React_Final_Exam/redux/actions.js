import axios from 'axios';

// Action Types
export const FETCH_STUDENTS_REQUEST = 'FETCH_STUDENTS_REQUEST';
export const FETCH_STUDENTS_SUCCESS = 'FETCH_STUDENTS_SUCCESS';
export const FETCH_STUDENTS_FAILURE = 'FETCH_STUDENTS_FAILURE';
export const ADD_STUDENT = 'ADD_STUDENT';
export const DELETE_STUDENT = 'DELETE_STUDENT';

// Fetch Students Actions
export const fetchStudentsRequest = () => ({ type: FETCH_STUDENTS_REQUEST });
export const fetchStudentsSuccess = (students) => ({
  type: FETCH_STUDENTS_SUCCESS,
  payload: students,
});
export const fetchStudentsFailure = (error) => ({
  type: FETCH_STUDENTS_FAILURE,
  payload: error,
});

// Fetch Students Thunk
export const fetchStudents = () => async (dispatch) => {
  dispatch(fetchStudentsRequest());
  try {
    const response = await axios.get('http://localhost:5000/students');
    dispatch(fetchStudentsSuccess(response.data));
  } catch (error) {
    dispatch(fetchStudentsFailure(error.message));
  }
};

// Add Student Thunk
export const addStudent = (student) => async (dispatch) => {
  try {
    const response = await axios.post('http://localhost:3000/students', student);
    dispatch({ type: ADD_STUDENT, payload: response.data });
  } catch (error) {
    console.error(error);
  }
};

// Delete Student Thunk
export const deleteStudent = (id) => async (dispatch) => {
  try {
    await axios.delete(`http://localhost:3000/students/${id}`);
    dispatch({ type: DELETE_STUDENT, payload: id });
  } catch (error) {
    console.error(error);
  }
};
